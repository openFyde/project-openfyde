#!/bin/bash

# https://gist.github.com/whitequark/2667695

RUNTIME=$1
ROOTFS_DIR=$2
PAYLOAD_DIR=$3
UPDATE_PKG=$4

print_usage(){
	echo "Usage: $0 <path to runc binary> <root dir> <payload dir> <update package>"
	echo
	exit 1
}


for arg in $@;do
	if [[ $arg == "--help" || $arg == "-h" ]]; then
		print_usage
	fi
done

if [[ "$PAYLOAD_DIR" == "" ]]; then
	print_usage
fi

install -o 655360 -g 655360 -d $ROOTFS_DIR/tmp/

cat >/tmp/android-update-shim.sh <<'END'
#!/tmp_bin/bash

set -e

if [[ ! $1 ]];then
	echo "Usage: $0 <update package>"
	echo
	exit 1
fi

UPDATE_PKG=$1
UPDATE_BINARY=META-INF/com/google/android/update-binary
FIFO=/tmp/update-fifo
echo "Installing package $UPDATE_PKG..."
rm -rf /tmp/update/
mkdir /tmp/update/
if ! busybox unzip -qo $UPDATE_PKG $UPDATE_BINARY -d /tmp/update/; then
	echo "Not an update package." >&2
	exit 1
fi
mkfifo $FIFO
exec 3<>$FIFO
rm -f $FIFO
echo "Launching update-binary..."
echo
TRAMPOLINE=$$
updater() {
	# update-binary <API version> <command fd> <update zip>
	chmod +x /tmp/update/$UPDATE_BINARY
	/tmp/update/$UPDATE_BINARY 3 3 $UPDATE_PKG 1>/dev/null 2>&1
	result_status=$?
	echo
	echo "return status: ${result_status}"
	if [ ${result_status} -eq 0 ]; then
		echo "Update was successful."
	else
		echo "Update has FAILED."
	fi
	rm -f /tmp/update/$UPDATE_BINARY
	kill $TRAMPOLINE
}
updater &
trap "exit" SIGTERM
while read -r line <&3; do
	line="${line} "
	cmd=${line%% *}
	args=${line#* }
	case $cmd in
	ui_print)
		if [ "$args" != "" ]; then
			echo "$args"
		fi
	esac
done
END

backup_file(){
	if [[ -f $1 && ! -f $1.nosuch ]]; then
		if [[ -f $1.bak ]]; then
			rm -f $1
		else
			mv $1 $1.bak
		fi
	else
		touch $1.nosuch
	fi
}

restore_file(){
	rm -f $1
	if [[ -f $1.nosuch ]]; then
		rm -f $1.nosuch
	fi
	if [[ -f $1.bak ]]; then
		mv $1.bak $1
	fi
}

echo "Environment init..."
TMP_BIN_DIR=$ROOTFS_DIR/tmp_bin
TMP_BIN_FALLBAK_DIR=$ROOTFS_DIR/tmp_bin_fallbak
install -o 655360 -g 655360 -d $TMP_BIN_DIR
install -o 655360 -g 655360 -d $TMP_BIN_FALLBAK_DIR

install -o 655360 -g 655360 $PAYLOAD_DIR/strace+ $TMP_BIN_DIR/strace+
install -o 655360 -g 655360 $PAYLOAD_DIR/busybox $TMP_BIN_DIR/busybox
for i in $($PAYLOAD_DIR/busybox --list); 
do 
	if [[ ! -f $i ]];then
		ln -s -f /tmp_bin/busybox $TMP_BIN_FALLBAK_DIR/$i
	fi
done;

install -o 655360 -g 655360 $PAYLOAD_DIR/fake_getprop.sh $TMP_BIN_DIR/fake_getprop.sh
install -o 655360 -g 655360 $PAYLOAD_DIR/getprop_wrapper.sh $TMP_BIN_DIR/getprop
install -o 655360 -g 655360 $PAYLOAD_DIR/bash $TMP_BIN_DIR/bash
backup_file $ROOTFS_DIR/sbin/sh
ln -s -f /system/bin/sh $ROOTFS_DIR/sbin/sh


echo "Pushing trampoline..."

install -o 655360 -g 655360 -m 755 /tmp/android-update-shim.sh $ROOTFS_DIR/tmp/update-shim.sh
rm -f /tmp/android-update-shim.sh

echo "Pushing update..."

install -o 655360 -g 655360 "$UPDATE_PKG" $ROOTFS_DIR/tmp/update.zip

echo "Launching trampoline..."

echo "${RUNTIME}" | grep "runc" >/dev/null
if [[ $? -eq 0 ]]; then
	echo "use runc runtime to start env"
	${RUNTIME} kill arc-rec KILL
	${RUNTIME} run -b $ROOTFS_DIR/../ arc-rec
else
	echo "use run_oci runtime to start env"
	install -o android-root -g android-root -d /sys/fs/cgroup/cpu/android
	install -o android-root -g android-root -d /sys/fs/cgroup/cpuacct/android
	install -o android-root -g android-root -d /sys/fs/cgroup/cpuset/android
	install -o android-root -g android-root -d /sys/fs/cgroup/devices/android
	install -o android-root -g android-root -d /sys/fs/cgroup/freezer/android
	${RUNTIME} run -c $ROOTFS_DIR/../ arc-rec
fi

RUNTIME_RETURN=$?

echo "Clean..."
restore_file $ROOTFS_DIR/sbin/sh

rm -rf $ROOTFS_DIR/dev/*
rm -rf $ROOTFS_DIR/tmp/
rm -rf $TMP_BIN_DIR
rm -rf $TMP_BIN_FALLBAK_DIR
rm -f $ROOTFS_DIR/.bash_history


exit $RUNTIME_RETURN