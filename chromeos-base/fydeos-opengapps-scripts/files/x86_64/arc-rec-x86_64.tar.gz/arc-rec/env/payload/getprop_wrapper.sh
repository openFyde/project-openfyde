#!/tmp_bin/bash

# echo "args: $@"

/tmp_bin/bash /tmp_bin/fake_getprop.sh $@
