#!/tmp_bin/bash

declare -A PROP_MAP=()

FAKE_PROP_FILE_LIST=("/default.prop" "/system/build.prop" "/system/default.prop" "/data/local.prop")

collect_prop_from_file(){
	KEYS=(`cat $1 2>/dev/null | sed "s/^\s*\([^#=]*\)=\([^#=]*\)\s*/\1/;tx;d;:x"`)
	VALUES=(`cat $1 2>/dev/null | sed "s/^\s*\([^#=]*\)=\([^#=]*\)\s*/\2/;tx;d;:x"`)

	KEYS_LEN=${#KEYS[*]}

	for ((i=0; i<$KEYS_LEN; i ++))
	do
		PROP_MAP["${KEYS[$i]}"]="${VALUES[$i]}"
	done
}


collect_all_prop(){
	for FAKE_PROP_FILE in ${FAKE_PROP_FILE_LIST[@]}
	do
		collect_prop_from_file ${FAKE_PROP_FILE}
	done
}

dump_all_prop(){
	if [[ ${#PROP_MAP[@]} -eq 0 ]]; then
		# if the length of PROP_MAP is 0, then print a empty line
		echo
	else
		for key in ${!PROP_MAP[@]}
		do
			echo "[${key}]: [${PROP_MAP[${key}]}]"
		done		
	fi

}


getprop_by_key(){
	echo "${PROP_MAP[$1]}"
}

collect_all_prop

if [[ $1 ]]; then
	getprop_by_key $1
else
	dump_all_prop
fi

exit 0